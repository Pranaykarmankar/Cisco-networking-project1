import os
import io
from flask import Flask, render_template, request, send_file, redirect, url_for, session
from core.parser import parse_config
from core.topology import build_topology, build_topology_json
from core.validator import validate_network

# ✅ PDF generation
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4

app = Flask(__name__)
app.secret_key = "supersecret"  # Needed for session

# ------- App Folders -------
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# ------- Global State -------
parsed_results_global = []       # Parsed configuration details
parsed_topology_data = None      # JSON data for topology (for validation)
validation_results_global = []   # Validation results

ALLOWED_EXTENSIONS = {'.txt', '.cfg', '.dump'}


# ------- Helpers -------
def allowed_file(filename: str) -> bool:
    _, ext = os.path.splitext(filename.lower())
    return ext in ALLOWED_EXTENSIONS


def safe_join_uploads(rel_path: str) -> str:
    """
    Build a safe path under UPLOAD_FOLDER while preserving
    folder structure from webkitdirectory submissions.
    """
    # Normalize slashes coming from browser (Chrome sends forward slashes)
    rel_path = rel_path.replace("\\", "/")
    parts = [p for p in rel_path.split("/") if p not in ("", ".", "..")]
    full_path = os.path.join(app.config['UPLOAD_FOLDER'], *parts)
    return full_path


def format_bandwidth(bw_list):
    """
    Nicely format a device-level bandwidth list taken from parser output.
    Uses the first value as the device summary.
    """
    if not bw_list:
        return "Unknown"
    try:
        bw_int = int(bw_list[0])
        if bw_int >= 1000000:
            return f"{bw_int // 1000000} Gbps"
        elif bw_int >= 1000:
            return f"{bw_int // 1000} Mbps"
        return f"{bw_int} kbps"
    except Exception:
        return "Unknown"


def compute_device_mtu_display(device: dict) -> str:
    """
    Derive a device-level MTU display from parsed interfaces.
    - If interfaces have MTU values -> show unique list joined by comma
    - Otherwise -> assume Default 1500
    """
    mtus = []
    for iface in device.get("interfaces", []):
        mtu_val = iface.get("mtu")
        if mtu_val:
            try:
                mtus.append(str(int(mtu_val)))
            except Exception:
                mtus.append(str(mtu_val))

    if mtus:
        unique_mtus = sorted(set(mtus), key=lambda x: int(x) if x.isdigit() else x)
        return ", ".join(unique_mtus)
    else:
        return "1500"


# ------- Routes -------
@app.route('/')
def home():
    # Show uploaded files if present, else None
    parsed_data = session.get('parsed_data')
    uploaded_files = [d.get('router_name', 'Unknown') for d in parsed_data] if parsed_data else None
    return render_template('index.html', uploaded_files=uploaded_files)

# Reset endpoint
@app.route('/reset', methods=['POST'])
def reset():
    global parsed_results_global, parsed_topology_data, validation_results_global
    session.pop('parsed_data', None)
    parsed_results_global = []
    parsed_topology_data = None
    validation_results_global = []
    return redirect(url_for('home'))


@app.route('/upload', methods=['POST'])
def upload_files():
    """
    Accepts multiple files (from file picker or drag-drop folder).
    Filters only .txt, .cfg, .dump files.
    Stores parsed data in global memory and session.
    """
    global parsed_results_global
     # Clear previous parsed data from session before new upload
    session.pop('parsed_data', None)

    uploaded_files = request.files.getlist('configs')  # All files come here now
    parsed_results = []

    if not uploaded_files or all(f.filename.strip() == '' for f in uploaded_files):
        return "No files selected!", 400

    valid_extensions = ('.txt', '.cfg', '.dump')
    for file in uploaded_files:
        filename = file.filename.strip()
        if filename.lower().endswith(valid_extensions):
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            file.save(filepath)

            # Parse the file
            parsed_data = parse_config(filepath)
            parsed_data["bandwidth_display"] = format_bandwidth(parsed_data.get("bandwidth"))
            parsed_data["mtu_display"] = compute_device_mtu_display(parsed_data)

            parsed_results.append(parsed_data)
        else:
            # Skip unsupported files silently
            print(f"Skipping unsupported file: {filename}")

    if not parsed_results:
        return "No valid configuration files found! Please upload .txt, .cfg, or .dump files.", 400

    # ✅ Save globally and in session
    parsed_results_global = parsed_results
    session['parsed_data'] = parsed_results

    return redirect(url_for('parsed_data_view'))


@app.route("/parsed_data")
def parsed_data_view():
    """
    Renders parsed_data.html with results from session.
    """
    parsed_data = session.get('parsed_data')
    if not parsed_data:
        # Allow page to load gracefully with message
        return render_template("parsed_data.html", results=None, message="No parsed data available. Please upload configuration files.")
    return render_template("parsed_data.html", results=parsed_data)


@app.route('/topology')
def topology():
    """
    Build D3 topology JSON and render topology.html
    """
    global parsed_topology_data
    if not parsed_results_global:
        return "Please upload configs first."

    parsed_topology_data = build_topology_json(parsed_results_global)
    return render_template('topology.html', data=parsed_topology_data)


@app.route('/validate')
def validate():
    """
    Run validation on current topology and render validation page.
    """
    global validation_results_global

    if not parsed_results_global:
        return "Please upload configs first."

    topology_data = build_topology_json(parsed_results_global)
    issues = validate_network(topology_data)

    validation_results = []

    for device in topology_data["nodes"]:
        device_errors = []

        # Duplicate IPs
        for dup in issues.get("duplicate_ips", []):
            if device["id"] in dup["devices"]:
                device_errors.append(f"Duplicate IP {dup['ip']}")

        # VLAN conflicts
        for vlan_conflict in issues.get("vlan_conflicts", []):
            if device["id"] in vlan_conflict["devices"]:
                device_errors.append(f"VLAN conflict: VLAN {vlan_conflict['vlan']}")

        # VLAN inconsistency
        for vlan_inc in issues.get("vlan_inconsistency", []):
            if device["id"] in vlan_inc["missing_on"]:
                device_errors.append(f"VLAN {vlan_inc['vlan']} missing on this device")

        # Gateway issues
        for gw_issue in issues.get("gateway_issues", []):
            device_ips = [iface.get("ip") for iface in device.get("interfaces", []) if iface.get("ip")]
            if any(ip in device_ips for ip in gw_issue["ips"]):
                device_errors.append(f"Missing gateway (.1) in subnet {gw_issue['subnet']}")

        # MTU mismatch
        for mtu_issue in issues.get("mtu_mismatch", []):
            if device["id"] in mtu_issue["link"]:
                device_errors.append(f"MTU mismatch on link {mtu_issue['link']}")

        # Loops
        for loop in issues.get("loops", []):
            if device["id"] in loop:
                device_errors.append(f"Loop detected: {' → '.join(loop)}")

        # Conflicting routing protocols
        for proto_issue in issues.get("conflicting_protocols", []):
            if device["id"] == proto_issue["device"]:
                device_errors.append(f"Conflicting routing protocols: {', '.join(proto_issue['protocols'])}")

        validation_results.append({
            "router_name": device.get("id", "Unknown"),
            "routing_protocols": device.get("routing_protocols", []),
            "vlans": device.get("vlans", []),
            "interfaces": device.get("interfaces", []),
            "bandwidth": device.get("bandwidth", "Unknown"),
            "mtu": device.get("mtu", "1500"),
            "errors": device_errors
        })

    validation_results_global = validation_results
    return render_template("validation.html", issues=validation_results)


@app.route("/download_report")
def download_report():
    """
    Generate a clean, professional PDF from validation_results_global.
    - Fits within A4 properly (no overflow)
    - Bandwidth/MTU identical to what's shown on the validation page
    - Includes validation errors per device
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=24,
        rightMargin=24,
        topMargin=24,
        bottomMargin=24
    )

    styles = getSampleStyleSheet()
    cell_style = ParagraphStyle(
        'Cell',
        parent=styles['Normal'],
        fontSize=9,
        leading=11
    )

    story = []
    story.append(Paragraph("Network Validation Report", styles["Title"]))
    story.append(Spacer(1, 12))

    if not validation_results_global:
        story.append(Paragraph("⚠ No validation results available. Please run validation first.", styles["Normal"]))
    else:
        header = ["Device", "Routing Protocols", "VLANs", "Bandwidth", "MTU", "Errors"]
        data = [header]

        for device in validation_results_global:
            errors_str = "\n".join(device.get("errors", [])) if device.get("errors") else "No errors"
            data.append([
                device.get("router_name", "Unknown"),
                ", ".join(device.get("routing_protocols", [])) if device.get("routing_protocols") else "None",
                ", ".join(str(v) for v in device.get("vlans", [])) if device.get("vlans") else "None",
                device.get("bandwidth", "Unknown"),
                str(device.get("mtu", "1500")),
                Paragraph(errors_str, cell_style)
            ])

        col_widths = [90, 100, 110, 90, 60, 95]
        table = Table(data, hAlign='LEFT', colWidths=col_widths, repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#2563eb")),
            ("TEXTCOLOR", (0,0), (-1,0), colors.whitesmoke),
            ("ALIGN", (0,0), (-1,-1), "LEFT"),
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,-1), 9),
            ("BOTTOMPADDING", (0,0), (-1,0), 8),
            ("GRID", (0,0), (-1,-1), 0.5, colors.grey),
            ("VALIGN", (0,0), (-1,-1), "TOP"),
        ]))
        story.append(table)

    doc.build(story)
    buffer.seek(0)
    return send_file(buffer, as_attachment=True,
                     download_name="validation_report.pdf",
                     mimetype="application/pdf")


if __name__ == '__main__':
    app.run(debug=True)
