# ConfigView :==> Cisco Network Simulator

A web-based tool for uploading, parsing, visualizing, and validating Cisco router configuration files.  
Built with Flask, Tailwind CSS, D3.js, Networkx and PyVis.

--- 

## Features

- **Upload Cisco router configs** (`.dump`, `.txt`, `.cfg` files) via web interface
- **Parse configuration files** to extract:
    Information Like
  - Router name
  - Interfaces (IP, bandwidth, MTU)
  - VLANs
  - Routing protocols (OSPF, BGP, etc.) , etc
- **Visualize network topology** interactively (D3.js, PyVis)
  **Download topology image** as png
- **Validate network** for:
  - Duplicate IPs
  - VLAN conflicts & inconsistencies
  - MTU mismatches
  - Gateway issues
  - Routing protocol conflicts
  - Network loops
- **Download validation report** as PDF
- **Responsive UI** with Tailwind CSS

---

## Project Structure

```
cisco-network-simulator/
│
├── app.py                  # Main Flask app
├── core/
│   ├── parser.py           # Config file parser
│   ├── topology.py         # Topology builder
│   └── validator.py        # Network validation logic
├── templates/
│   ├── layout.html         # Base template
│   ├── index.html          # Home page
│   ├── parsed_data.html    # Parsed config details
│   ├── topology.html       # Topology visualization
│   ├── validation.html     # Validation results
├── static/
│   ├── css/
│   │   |── style.css       # Tailwind CSS (compiled)
|   |   ├── tailwind.css    # Tailwind CSS (imported)     
├── uploads/                # Uploaded config files (as a example)
├── .gitignore
└── README.md
```

## Python Libraries Used

Below are all libraries from `requirements.txt` and their uses in this project:

---

### **Web Framework & Core**
- **Flask**: Main web framework for routing, templates, and request handling.
- **gunicorn**: Production WSGI server for deploying Flask apps on render.

### **Templating & HTML**
- **Jinja2**: Templating engine for rendering HTML pages.

### **Network & Visualization**
- **networkx**: For building and analyzing network graphs (topology, validation, loop detection).
- **pyvis and D3.js**: For generating interactive network visualizations (topology).

### **PDF Generation**
- **reportlab**: For generating PDF validation reports.

---

## Getting Started

### Prerequisites

- Python 3.8+
- [pip](https://pip.pypa.io/en/stable/)
- Node.js & npm (for Tailwind CSS build, optional)

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/yourusername/cisco-network-simulator.git
   cd cisco-network-simulator
   ```

2. **Create a virtual environment:**
   ```bash
   python -m venv venv
   source venv/bin/activate   # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **(Optional) Build Tailwind CSS:**
   If you want to customize styles, run:
   ```bash
   npm install
   npx tailwindcss -i ./static/css/input.css -o ./static/css/ style.css --minify
   ```

---

## Usage

1. **Run the Flask app:**
   ```bash
   python app.py
   ```
   The app will be available at [http://localhost:5000](http://localhost:5000).

2. **Upload router config files** on the home page.

3. **View parsed configuration details**.

4. **Visualize network topology** interactively.

5. **Validate network** and download PDF reports.

---