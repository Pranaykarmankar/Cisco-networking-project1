import re
import networkx as nx
from pyvis.network import Network

# ---------- Bandwidth helpers (minimal, safe change) ----------

def _to_kbps(value):
    """
    Convert various bandwidth representations to kbps (int).
    Accepts numbers, numeric strings, or strings with units (Gbps/Mbps/kbps).
    Returns None if it cannot parse.
    """
    if value is None:
        return None

    # direct int/float
    if isinstance(value, (int, float)):
        return int(value)

    # list/tuple: take max known
    if isinstance(value, (list, tuple)) and value:
        parsed = [_to_kbps(v) for v in value]
        parsed = [p for p in parsed if p is not None]
        return max(parsed) if parsed else None

    # string: try with units
    if isinstance(value, str):
        s = value.strip().lower()
        # e.g., "1gbps", "100 mbps", "1000000", "1g", "100m"
        m = re.match(r'^(\d+(?:\.\d+)?)\s*([a-zA-Z]+)?$', s)
        if m:
            num = float(m.group(1))
            unit = (m.group(2) or '').lower()

            # normalize unit variants
            if unit in ('gbps', 'g', 'gbit', 'giga', 'gig'):
                return int(num * 1_000_000)   # kbps
            if unit in ('mbps', 'm', 'mbit', 'mega', 'meg'):
                return int(num * 1_000)       # kbps
            if unit in ('kbps', 'k', 'kbit', 'kilo'):
                return int(num)               # kbps
            if unit == '' or unit.isdigit():
                # no unit: assume it's already kbps-like integer string
                try:
                    return int(float(s))
                except:
                    return None

        # as a final fallback, try plain int
        try:
            return int(float(s))
        except:
            return None

    return None


def _infer_kbps_from_interfaces(interfaces):
    """
    Infer bandwidth from interface names when explicit bandwidth is missing.
    TenGig > Gigabit > FastEthernet.
    Returns kbps or None.
    """
    if not interfaces:
        return None
    best = None
    for iface in interfaces:
        name = (iface.get("name") or "").lower()
        # Common Cisco-style shortcuts included
        if any(tag in name for tag in ("tengig", "ten-gig", "10g", "te")):
            best = max(best or 0, 10_000_000)  # 10 Gbps in kbps
        elif any(tag in name for tag in ("gigabit", "gi")):
            best = max(best or 0, 1_000_000)   # 1 Gbps in kbps
        elif any(tag in name for tag in ("fast", "fa")):
            best = max(best or 0, 100_000)     # 100 Mbps in kbps
    return best


def format_bandwidth(kbps):
    """Pretty print kbps -> 'X Gbps / Y Mbps / Z kbps'."""
    try:
        if kbps is None:
            return "Unknown"
        kbps = int(kbps)
        if kbps >= 1_000_000:
            return f"{kbps // 1_000_000} Gbps"
        if kbps >= 1_000:
            return f"{kbps // 1_000} Mbps"
        return f"{kbps} kbps"
    except:
        return "Unknown"


def _device_kbps(router):
    """
    Decide a device-level bandwidth kbps:
    1) router['bandwidth'] (max if list)
    2) infer from interfaces
    """
    explicit = _to_kbps(router.get("bandwidth"))
    if explicit is not None:
        return explicit
    return _infer_kbps_from_interfaces(router.get("interfaces") or [])


# ---------- Existing visual builders (unchanged except bandwidth plumbing) ----------

def build_topology(parsed_results, output_path="static/topology.html"):
    """
    Build topology visualization with PyVis and save to HTML.
    """
    G = nx.Graph()

    # Add nodes
    for router in parsed_results:
        if router["router_name"]:
            G.add_node(router["router_name"], shape="circle", color="#007bff")

    # Add edges
    for i in range(len(parsed_results)):
        for j in range(i + 1, len(parsed_results)):
            r1 = parsed_results[i]
            r2 = parsed_results[j]

            common = set(r1["networks"]).intersection(set(r2["networks"]))
            if common:
                # --- FIXED: reliable bandwidth for edge as min of endpoints ---
                bw1 = _device_kbps(r1)
                bw2 = _device_kbps(r2)
                edge_kbps = None
                if bw1 is not None and bw2 is not None:
                    edge_kbps = min(bw1, bw2)
                else:
                    # final fallback from r1 interface type
                    edge_kbps = _infer_kbps_from_interfaces(r1.get("interfaces") or [])

                bw_display = format_bandwidth(edge_kbps)

                vlan_info = f"{', '.join(r1['vlans']) if r1['vlans'] else 'None'} | {', '.join(r2['vlans']) if r2['vlans'] else 'None'}"
                rp1 = r1['routing_protocol'] if r1['routing_protocol'] else 'None'
                rp2 = r2['routing_protocol'] if r2['routing_protocol'] else 'None'

                # Try to find interfaces that match common network (best effort)
                iface1_info, iface2_info = "Not Found", "Not Found"
                net_prefixes = [net.split("/")[0] for net in common]
                for iface in r1.get("interfaces", []):
                    if iface.get("ip") and any(iface["ip"].startswith(pfx) for pfx in net_prefixes):
                        iface1_info = f"{iface['name']} ({iface['ip']})"
                        break
                for iface in r2.get("interfaces", []):
                    if iface.get("ip") and any(iface["ip"].startswith(pfx) for pfx in net_prefixes):
                        iface2_info = f"{iface['name']} ({iface['ip']})"
                        break

                tooltip = f"{iface1_info} ↔ {iface2_info} | BW: {bw_display}"

                # Full details HTML
                edge_info = f"""
                <div style='font-family:Arial; font-size:14px;'>
                  <b>{r1['router_name']} ↔ {r2['router_name']}</b><br><br>
                  <table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse; width:100%;'>
                    <tr><th>Parameter</th><th>Value</th></tr>
                    <tr><td>Interfaces</td><td>{iface1_info} ↔ {iface2_info}</td></tr>
                    <tr><td>Bandwidth</td><td>{bw_display}</td></tr>
                    <tr><td>Common Network</td><td>{', '.join(common)}</td></tr>
                    <tr><td>VLANs</td><td>{vlan_info}</td></tr>
                    <tr><td>Routing Protocols</td><td>{rp1} | {rp2}</td></tr>
                  </table>
                </div>
                """

                G.add_edge(
                    r1["router_name"],
                    r2["router_name"],
                    title=tooltip,
                    custom=edge_info
                )

    net = Network(height="600px", width="100%", bgcolor="#ffffff", font_color="black")
    net.from_nx(G)

    net.toggle_physics(False)
    net.set_options("""
    {
      "layout": {
        "hierarchical": {
          "enabled": true,
          "levelSeparation": 200,
          "nodeSpacing": 150,
          "treeSpacing": 200,
          "direction": "LR"
        }
      },
      "nodes": {
        "shape": "circle",
        "color": { "background": "#001b2e", "border": "#004085" },
        "font": { "size": 22, "color": "#ffffff" }
      },
      "edges": {
        "smooth": true,
        "color": { "color": "#555", "highlight": "#ff0000" },
        "font": { "size": 12, "align": "middle" }
      }
    }
    """)

    net.write_html(output_path, notebook=False, local=True)
    return output_path


def build_topology_json(parsed_results):
    """
    Build topology data in JSON for D3 visualization.
    Returns: dict with 'nodes' and 'links'
    """
    nodes = []
    links = []

    # Nodes with full info (bandwidth fixed)
    for r in parsed_results:
        if not r.get("router_name"):
            continue

        dev_kbps = _device_kbps(r)
        mtus = [iface.get("mtu") for iface in r.get("interfaces", []) if iface.get("mtu")]
        dev_mtu = min(mtus) if mtus else 1500
        nodes.append({
            "id": r["router_name"],
            "interfaces": r.get("interfaces", []),
            "vlans": r.get("vlans", []),
            "routing_protocols": r.get("routing_protocols", []),  # <-- Use list
            "bandwidth": format_bandwidth(dev_kbps),
            "mtu": dev_mtu
        })        

    # Links
    for i in range(len(parsed_results)):
        for j in range(i + 1, len(parsed_results)):
            r1 = parsed_results[i]
            r2 = parsed_results[j]

            common = set(r1.get("networks", [])).intersection(set(r2.get("networks", [])))
            if not common:
                continue

            # ✅ min of endpoints (in kbps), then format
            bw1 = _device_kbps(r1)
            bw2 = _device_kbps(r2)
            edge_kbps = None
            if bw1 is not None and bw2 is not None:
                edge_kbps = min(bw1, bw2)
            else:
                edge_kbps = _infer_kbps_from_interfaces(r1.get("interfaces") or [])

            vlan_info = ",".join((r1.get("vlans") or []) + (r2.get("vlans") or [])) or "None"
            mtu = r1.get("mtu") or r2.get("mtu") or "1500"

            links.append({
                "source": r1["router_name"],
                "target": r2["router_name"],
                "bandwidth": format_bandwidth(edge_kbps),  # ✅ formatted string
                "vlans": vlan_info,
                "mtu": mtu
            })

    return {"nodes": nodes, "links": links}
