import networkx as nx

def validate_network(data):
    issues = {
        "duplicate_ips": [],
        "vlan_conflicts": [],
        "gateway_issues": [],
        "mtu_mismatch": [],
        "loops": [],
        "conflicting_protocols": [],
        "vlan_inconsistency": []
    }

    ip_map = {}
    vlan_map = {}
    device_map = {node["id"]: node for node in data["nodes"]}

    # 1. Duplicate IPs
    for node in data["nodes"]:
        for iface in node.get("interfaces", []):
            if iface.get("ip"):
                ip = iface["ip"]
                if ip in ip_map:
                    issues["duplicate_ips"].append({
                        "ip": ip,
                        "devices": [ip_map[ip], node["id"]]
                    })
                else:
                    ip_map[ip] = node["id"]

    # 2. VLAN conflicts
    for node in data["nodes"]:
        for vlan in node.get("vlans", []):
            vlan_map.setdefault(vlan, []).append(node["id"])

    for vlan, devices in vlan_map.items():
        if len(devices) > 1:
            issues["vlan_conflicts"].append({
                "vlan": vlan,
                "devices": devices
            })

    # 2b. VLAN consistency: VLAN present but not on all devices
    all_vlans = set(vlan_map.keys())
    for vlan in all_vlans:
        missing = [node["id"] for node in data["nodes"] if vlan not in node.get("vlans", [])]
        if missing and len(vlan_map[vlan]) > 1:
            issues["vlan_inconsistency"].append({
                "vlan": vlan,
                "missing_on": missing
            })

    # 3. Gateway correctness
    subnet_gateways = {}
    for node in data["nodes"]:
        for iface in node.get("interfaces", []):
            if iface.get("ip"):
                ip = iface["ip"]
                subnet = ".".join(ip.split(".")[:3])
                subnet_gateways.setdefault(subnet, []).append(ip)

    for subnet, ips in subnet_gateways.items():
        if not any(ip.endswith(".1") for ip in ips):
            issues["gateway_issues"].append({
                "subnet": subnet,
                "ips": ips
            })

    # 4. MTU mismatch on links
    for link in data["links"]:
        src = link["source"]
        tgt = link["target"]

        src_mtu = None
        tgt_mtu = None

        if src in device_map:
            for iface in device_map[src].get("interfaces", []):
                src_mtu = iface.get("mtu", 1500)
                break

        if tgt in device_map:
            for iface in device_map[tgt].get("interfaces", []):
                tgt_mtu = iface.get("mtu", 1500)
                break

        if src_mtu and tgt_mtu and src_mtu != tgt_mtu:
            issues["mtu_mismatch"].append({
                "link": f"{src} ↔ {tgt}",
                "src_mtu": src_mtu,
                "tgt_mtu": tgt_mtu
            })

    # 5. Loops (Cycle detection)
    G = nx.Graph()
    for link in data["links"]:
        G.add_edge(link["source"], link["target"])

    cycles = list(nx.cycle_basis(G))
    for cycle in cycles:
        issues["loops"].append(cycle)

    # 6. Conflicting routing protocols
    for node in data["nodes"]:
        protocols = node.get("routing_protocols", [])
        if len(protocols) > 1:
            issues["conflicting_protocols"].append({
                "device": node["id"],
                "protocols": protocols
            })

    return issues
