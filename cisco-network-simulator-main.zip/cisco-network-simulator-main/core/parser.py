import re

def parse_config(file_path):
    """
    Parse router configuration file and extract:
    - Router name
    - Interfaces with IPs, Bandwidth, MTU
    - VLAN IDs
    - Routing protocol (OSPF/BGP)
    - Network prefixes (for connectivity)
    """
    data = {
        "router_name": None,
        "interfaces": [],      # [{name, ip, bandwidth, mtu}]
        "bandwidth": [],       # aggregated list
        "vlans": [],
        "routing_protocol": None,
        "networks": []         # Used to find adjacency
    }

    try:
        with open(file_path, 'r') as f:
            content = f.read()

        # Extract hostname
        hostname_match = re.search(r'^hostname\s+(\S+)', content, re.MULTILINE)
        if hostname_match:
            data["router_name"] = hostname_match.group(1)

        # Extract all interface blocks (captures the whole section until next "!")
        interface_blocks = re.findall(r'(?:^interface\s+\S+[\s\S]*?)(?=^!)', content, re.MULTILINE)

        for block in interface_blocks:
            iface = {}
            # Interface name
            name_match = re.search(r'^interface\s+(\S+)', block, re.MULTILINE)
            if name_match:
                iface["name"] = name_match.group(1)

            # IP Address
            ip_match = re.search(r'ip address\s+(\d+\.\d+\.\d+\.\d+)\s+\d+\.\d+\.\d+\.\d+', block)
            if ip_match:
                iface["ip"] = ip_match.group(1)
                prefix = ".".join(iface["ip"].split(".")[:3])
                data["networks"].append(prefix)
            else:
                iface["ip"] = None

            # Bandwidth (if configured)
            bw_match = re.search(r'bandwidth\s+(\d+)', block)
            if bw_match:
                iface["bandwidth"] = bw_match.group(1)
                data["bandwidth"].append(bw_match.group(1))
            else:
                iface["bandwidth"] = None

            # MTU (if configured)
            mtu_match = re.search(r'mtu\s+(\d+)', block)
            if mtu_match:
                iface["mtu"] = mtu_match.group(1)
            else:
                iface["mtu"] = None

            data["interfaces"].append(iface)

        # Extract VLANs
        vlans = re.findall(r'^vlan\s+(\d+)', content, re.MULTILINE)
        data["vlans"] = vlans

        # Detect routing protocols (all present)
        protocols = []
        if re.search(r'router ospf', content, re.IGNORECASE):
            protocols.append("OSPF")
        if re.search(r'router bgp', content, re.IGNORECASE):
            protocols.append("BGP")
        # Add more protocols if needed

        data["routing_protocols"] = protocols

    except Exception as e:
        print(f"Error parsing {file_path}: {e}")

    return data
